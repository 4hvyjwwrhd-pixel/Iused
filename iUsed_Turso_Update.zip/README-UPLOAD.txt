iUsed Turso Update

ارفع server.js و package.json إلى جذر مستودع GitHub بدل النسخ القديمة.
لا تحذف مجلد public الحالي.

Render Environment Variables المطلوبة:
TURSO_DATABASE_URL
TURSO_AUTH_TOKEN
ADMIN_PASSWORD
SESSION_SECRET

بعد رفع الملفات، Render سيعمل Deploy تلقائياً إذا كان Auto Deploy مفعلاً.
